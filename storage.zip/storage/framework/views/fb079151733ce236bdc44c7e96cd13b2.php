<?php $__env->startComponent('mail::message'); ?>
# Halo, Gamer!

Terima kasih telah mendaftar di **<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>**. Kami mendeteksi upaya pendaftaran akun menggunakan alamat email ini.

Silakan gunakan kode verifikasi di bawah ini untuk mengaktifkan akun Anda:

<?php $__env->startComponent('mail::panel'); ?>
<div style="text-align: center;">
<h1 style="margin: 0; font-size: 42px; letter-spacing: 12px; color: #fbbf24;"><?php echo new \Illuminate\Support\EncodedHtmlString($otp); ?></h1>
</div>
<?php echo $__env->renderComponent(); ?>

Kode OTP ini bersifat rahasia dan akan kedaluwarsa dalam **15 menit**.

Jika Anda tidak merasa mendaftar di layanan kami, Anda dapat mengabaikan email ini dengan aman.

Salam,<br>
Tim <?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/spdfrasy/mall/resources/views/emails/otp.blade.php ENDPATH**/ ?>